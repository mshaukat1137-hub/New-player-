package com.example.simplevideoplayer

import android.content.Context
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GestureDetectorCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.example.simplevideoplayer.databinding.ActivityMainBinding
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private var player: ExoPlayer? = null
    private var isMuted = false
    private var currentSpeed = 1f
    private var isFullscreen = false
    private var currentBrightness = 0.5f
    private lateinit var audioManager: AudioManager
    private lateinit var gestureDetector: GestureDetectorCompat
    private val overlayHandler = Handler(Looper.getMainLooper())
    private val hideGestureOverlay = Runnable { binding.gestureGuide.visibility = View.GONE }

    private val pickVideo = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            binding.tvNowPlaying.text = getString(R.string.local_video_selected)
            binding.tvVideoHint.text = getString(R.string.local_file_hint)
            playVideo(it)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        currentBrightness = if (window.attributes.screenBrightness > 0f) {
            window.attributes.screenBrightness
        } else {
            0.5f
        }

        setupGestureControls()
        setupClickListeners()
        showGestureMessage(getString(R.string.gesture_default_title), getString(R.string.gesture_default_subtitle), 3000L)
    }

    private fun setupClickListeners() {
        binding.btnPlayUrl.setOnClickListener {
            val url = binding.etVideoUrl.text?.toString()?.trim().orEmpty()
            if (url.isEmpty()) {
                Toast.makeText(this, R.string.enter_video_url, Toast.LENGTH_SHORT).show()
            } else {
                binding.tvNowPlaying.text = getString(R.string.streaming_video)
                binding.tvVideoHint.text = url
                playVideo(Uri.parse(url))
            }
        }

        binding.btnPickVideo.setOnClickListener {
            pickVideo.launch("video/*")
        }

        binding.btnReplay10.setOnClickListener {
            player?.seekTo((player?.currentPosition ?: 0L) - 10_000L)
        }

        binding.btnForward10.setOnClickListener {
            player?.seekTo((player?.currentPosition ?: 0L) + 10_000L)
        }

        binding.btnMute.setOnClickListener {
            player?.let {
                isMuted = !isMuted
                it.volume = if (isMuted) 0f else 1f
                binding.btnMute.text = getString(if (isMuted) R.string.unmute else R.string.mute)
                showGestureMessage(
                    getString(R.string.audio_changed, if (isMuted) 0 else 100),
                    getString(R.string.gesture_volume_subtitle)
                )
            }
        }

        binding.btnSpeed.setOnClickListener {
            player?.let {
                currentSpeed = when (currentSpeed) {
                    1f -> 1.25f
                    1.25f -> 1.5f
                    1.5f -> 2f
                    else -> 1f
                }
                it.setPlaybackSpeed(currentSpeed)
                binding.btnSpeed.text = getString(R.string.speed_value, currentSpeed)
                showGestureMessage(
                    getString(R.string.speed_value, currentSpeed),
                    getString(R.string.gesture_seek_subtitle)
                )
            }
        }

        binding.btnFullscreen.setOnClickListener {
            toggleFullscreen()
        }
    }

    private fun setupGestureControls() {
        gestureDetector = GestureDetectorCompat(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (binding.gestureGuide.visibility == View.VISIBLE) {
                    binding.gestureGuide.visibility = View.GONE
                } else {
                    showGestureMessage(
                        getString(R.string.gesture_default_title),
                        getString(R.string.gesture_default_subtitle),
                        1800L
                    )
                }
                return true
            }
        })

        binding.gestureTouchLayer.setOnTouchListener(object : View.OnTouchListener {
            private var downX = 0f
            private var downY = 0f
            private var isSeeking = false
            private var isBrightnessGesture = false
            private var isVolumeGesture = false
            private var startPosition = 0L
            private var startBrightness = currentBrightness
            private var startVolume = 0

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                gestureDetector.onTouchEvent(event)
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = event.x
                        downY = event.y
                        isSeeking = false
                        isBrightnessGesture = false
                        isVolumeGesture = false
                        startPosition = player?.currentPosition ?: 0L
                        startBrightness = currentBrightness
                        startVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                        overlayHandler.removeCallbacks(hideGestureOverlay)
                        return true
                    }

                    MotionEvent.ACTION_MOVE -> {
                        val deltaX = event.x - downX
                        val deltaY = event.y - downY
                        val width = v.width.toFloat().coerceAtLeast(1f)
                        val height = v.height.toFloat().coerceAtLeast(1f)

                        if (!isSeeking && !isBrightnessGesture && !isVolumeGesture) {
                            if (abs(deltaX) > abs(deltaY)) {
                                isSeeking = true
                            } else if (downX < width / 2f) {
                                isBrightnessGesture = true
                            } else {
                                isVolumeGesture = true
                            }
                        }

                        when {
                            isSeeking -> {
                                val seekOffsetMs = ((deltaX / width) * 90_000L).toLong()
                                val duration = player?.duration?.takeIf { it > 0 } ?: 0L
                                val targetPosition = (startPosition + seekOffsetMs).coerceIn(0L, duration)
                                player?.seekTo(targetPosition)
                                showGestureMessage(
                                    getString(R.string.seek_changed, formatTime(targetPosition)),
                                    getString(R.string.gesture_seek_subtitle),
                                    700L
                                )
                            }

                            isBrightnessGesture -> {
                                val change = -(deltaY / height)
                                currentBrightness = (startBrightness + change).coerceIn(0.1f, 1f)
                                window.attributes = window.attributes.apply {
                                    screenBrightness = currentBrightness
                                }
                                showGestureMessage(
                                    getString(R.string.brightness_changed, (currentBrightness * 100).roundToInt()),
                                    getString(R.string.gesture_brightness_subtitle),
                                    700L
                                )
                            }

                            isVolumeGesture -> {
                                val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                                val desiredVolume = (startVolume + (-(deltaY / height) * maxVolume).roundToInt())
                                    .coerceIn(0, maxVolume)
                                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, desiredVolume, 0)
                                isMuted = desiredVolume == 0
                                binding.btnMute.text = getString(if (isMuted) R.string.unmute else R.string.mute)
                                showGestureMessage(
                                    getString(R.string.audio_changed, ((desiredVolume * 100f) / maxVolume).roundToInt()),
                                    getString(R.string.gesture_volume_subtitle),
                                    700L
                                )
                            }
                        }
                        return true
                    }

                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        scheduleOverlayHide(1200L)
                        return true
                    }
                }
                return false
            }
        })
    }

    private fun initPlayer() {
        if (player == null) {
            player = ExoPlayer.Builder(this).build().also { exoPlayer ->
                binding.playerView.player = exoPlayer
                exoPlayer.addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) {
                        binding.tvStatus.text = getString(
                            if (isPlaying) R.string.status_playing else R.string.status_ready
                        )
                    }
                })
            }
        }
    }

    private fun playVideo(uri: Uri) {
        initPlayer()
        val mediaItem = MediaItem.fromUri(uri)
        player?.apply {
            setMediaItem(mediaItem)
            prepare()
            playWhenReady = true
            volume = if (isMuted) 0f else 1f
            setPlaybackSpeed(currentSpeed)
        }
    }

    private fun toggleFullscreen() {
        isFullscreen = !isFullscreen
        requestedOrientation = if (isFullscreen) {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }

        WindowCompat.setDecorFitsSystemWindows(window, !isFullscreen)
        WindowInsetsControllerCompat(window, binding.root).let { controller ->
            controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            if (isFullscreen) {
                controller.hide(WindowInsetsCompat.Type.systemBars())
            } else {
                controller.show(WindowInsetsCompat.Type.systemBars())
            }
        }

        binding.headerLayout.visibility = if (isFullscreen) View.GONE else View.VISIBLE
        binding.urlCard.visibility = if (isFullscreen) View.GONE else View.VISIBLE
        binding.rootLayout.setPadding(if (isFullscreen) 0 else dp(16), if (isFullscreen) 0 else dp(16), if (isFullscreen) 0 else dp(16), if (isFullscreen) 0 else dp(16))

        val params = binding.playerCard.layoutParams as LinearLayout.LayoutParams
        if (isFullscreen) {
            params.width = ViewGroup.LayoutParams.MATCH_PARENT
            params.height = 0
            params.weight = 1f
            params.topMargin = 0
            binding.playerCard.radius = 0f
            binding.btnFullscreen.text = getString(R.string.exit_fullscreen)
            showGestureMessage(getString(R.string.fullscreen_on), getString(R.string.fullscreen_hint))
        } else {
            params.width = ViewGroup.LayoutParams.MATCH_PARENT
            params.height = 0
            params.weight = 1f
            params.topMargin = dp(16)
            binding.playerCard.radius = dp(28).toFloat()
            binding.btnFullscreen.text = getString(R.string.fullscreen)
            showGestureMessage(getString(R.string.fullscreen_off), getString(R.string.gesture_default_subtitle))
        }
        binding.playerCard.layoutParams = params
    }

    private fun showGestureMessage(title: String, subtitle: String, autoHideDelay: Long = 1500L) {
        binding.tvGestureIndicator.text = title
        binding.tvGestureSubtext.text = subtitle
        binding.gestureGuide.visibility = View.VISIBLE
        scheduleOverlayHide(autoHideDelay)
    }

    private fun scheduleOverlayHide(delayMs: Long) {
        overlayHandler.removeCallbacks(hideGestureOverlay)
        overlayHandler.postDelayed(hideGestureOverlay, delayMs)
    }

    private fun formatTime(positionMs: Long): String {
        val totalSeconds = (positionMs / 1000).toInt()
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) {
            String.format("%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format("%02d:%02d", minutes, seconds)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).roundToInt()

    override fun onStart() {
        super.onStart()
        initPlayer()
    }

    override fun onStop() {
        super.onStop()
        overlayHandler.removeCallbacks(hideGestureOverlay)
        player?.release()
        player = null
    }
}
